# Supplementary materials — code and data

**Manuscript:** Grouped Validation of Hardness Models for Mechanically Alloyed
Al–Mn–Zr-Based Alloys after Hot-Press Consolidation
**Authors:** Mintesenot Admasu Eshetu, Alexander S. Novikov
**Journal:** Science of Sintering

This folder is the complete **Supplementary Code S1** and **Supplementary
Data S1** package referenced in the manuscript's Data/Code availability
statements. One script, run against one CSV file, regenerates every
statistic, table value and figure reported in the main text and the
Supplementary Information.

**Dataset note (current version).** `Supplementary_Data_S1_clean_dataset.csv`
was re-issued by the authors to make the `grain_size` and `density` columns
numerically uniform (e.g. `27.02777778` → `27`, `2.772380952` → `2.77`);
these were residual full-precision artefacts of an earlier unit-conversion
step in the lab's original processing pipeline, not re-measurements, and the
correction is consistent with the dataset-provenance statement in main text
Section 2.3.1. Because `grain_size` and `density` feed into M1 and M3 (but
not M2, which uses only process/formulation inputs), this changed M1's and
M3's point estimates and intervals by a small amount; M2's results —
including the primary M2-RF-vs-M3-RF comparison's conclusion — are
unaffected in direction, though the exact p-value moved (see Results 3.1).
Every number in this package, the manuscript and the Supplementary
Information was re-verified end-to-end against the current CSV before this
version was issued.

---

## 1. File manifest

| File | What it is |
|---|---|
| `Supplementary_Code_S1_analysis.py` | The complete analysis script (Supplementary Code S1). Self-contained: loads the data, engineers features, fits every model, runs every validation scheme, and saves every figure. |
| `Supplementary_Data_S1_clean_dataset.csv` | The audited, specimen-level dataset (Supplementary Data S1): 42 rows, one per specimen. See the data dictionary in §4 below. |
| `requirements.txt` | The exact package versions the script was verified against. `pip install -r requirements.txt`. |
| `README.md` | This file. |
| `run_output_reference.log` | A full console transcript from a verified run of the script, included so you can diff your own output against ours without having to re-run anything first. |
| `fig_S1_baseline_comparison.png` … `fig_S8_parity_M2RF.png` | The eight figures the script generates, pre-rendered and numbered to match the Supplementary Information's Figure S1–S8 (see the map in §3). Regenerated fresh by every run of the script. |

---

## 2. How to run it

```bash
# 1. (recommended) create a clean environment
python3 -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate

# 2. install the exact verified dependency versions
pip install -r requirements.txt

# 3. run — must be launched from this directory, so the script finds the CSV
python3 Supplementary_Code_S1_analysis.py
```

That's it — no command-line arguments, no config file, no external data
download. The script prints every reported number to stdout, organised
into labelled blocks (see §3), and writes eight `.png` figures into the
current directory.

**Expected runtime:** roughly 8–10 minutes on one modern CPU core. There is
no GPU use and no parallelism — the cost is almost entirely the four
case-resampling / bootstrap loops (10,000, 10,000, 5,000 and 6×10,000
iterations respectively) and one SHAP `TreeExplainer` call. If you want a
much faster smoke-test, read "Speeding it up" in §5.

**Verifying your run matches ours:** compare your console output against
`run_output_reference.log`, line by line if you like — every seed used in
the script is fixed (see §5), so re-running it should reproduce every
printed number exactly, not just approximately. The point estimates and
intervals you should see are also quoted directly in the manuscript and
Supplementary Information tables, so a spot check against either source
works too.

---

## 3. Map: script section → manuscript / Supplementary Information location

The script is organised into twelve numbered sections (search for
`# === N.` in the file). Each one is labelled, in both the code comment
and the printed header, with exactly where its output is used:

| § | What it computes | Reported in |
|---|---|---|
| 1 | LOOCV performance (M1, M2-OLS\*, M2-RF, M3-RF), 95% case-resampling intervals; plus the two 7-feature M3 descriptor-redundancy variants (crystallite-size-only, HP-only) | Methods 2.4, Results 3.1, Results 3.3; **Supplementary Tables S21, S17**; `fig_S8_parity_M2RF.png` |
| 2 | Grouped cross-validation: LOCO and LOAO per model, plus the LOAO per-family means and the grouped no-skill baseline | Methods 2.4, Results 3.2; **Supplementary Table S20** |
| 3 | Repeated 5-fold CV, 20 seeds | Results 3.4 |
| 4 | Baseline comparison: 7 regressors + mean no-skill, on the M2 feature set | Results 3.1; **Supplementary Table S14**; `fig_S1_baseline_comparison.png` |
| 5 | M1 coefficients, bootstrap percentile 95% CI (5,000 refits) | Results 3.3; **Supplementary Table S18**; `fig_S3_coefficients.png` |
| 6 / 6b | M2-RF residual diagnostics, and sensitivity to the two largest-residual specimens | Results 3.4; `fig_S2_residual_diagnostics.png` |
| 7 | SHAP values and permutation importance (M3, M2) | Results 3.3; **Supplementary Table S17**/discussion; `fig_S6_shap_beeswarm.png` |
| 8 | Family-specific Hall–Petch-like regressions + heterogeneity F-test; plus the pooled (family-ignoring) correlation between crystallite size and hardness | Results 3.3; `fig_S7_hallpetch.png` |
| 9 | Exploratory hardness-vs-UTS correlation; paired post-treatment-to-as-processed hardness ratio | Results 3.3; **Supplementary Table S5**; `fig_S4_uts_hv.png`, `fig_S5_post_treatment_ratio.png`\*\* |
| 10 | Retrospective surrogate-ranking illustration (grid search + 10-seed robustness) — descriptive only, **not** a validated recommendation (H4) | Results 3.4 |
| 11 | Paired case-resampling tests between every model pair (the empirical p-values) | Methods 2.4, Results 3.1 — the primary, pre-specified **M2-RF-vs-M3-RF** test is the first line printed; the rest are exploratory |
| 12 | LOAO encoding-mechanics check — confirms the Ce-indicator coefficient collapses to ≈0 when the Ce family is withheld | Results 3.2 (the ≈4×10⁻¹³ value quoted in the LOAO discussion; the exact sign/magnitude is not meaningful, only that it collapses to ~0) |

\* M2-OLS is fit in §11 (`pred_M2_OLS`), alongside the paired tests, rather
than in §1 with M1/M2-RF/M3-RF — it uses the identical M2 feature set and
LOOCV split, just a different estimator, so its R²/RMSE/MAE point
estimates can be read off the §11 printout or recomputed in one line
(`cross_val_predict(LinearRegression(), X2, y, cv=loo)`), and its bootstrap
interval uses the same `bootstrap_ci()` helper as the other three models.

\*\* The published Supplementary Information shows these two panels side
by side as one composite "Figure S4–S5"; the script saves them as two
separate files so each plot's generating code stays self-contained — just
place them next to each other to reproduce the published layout.

---

## 4. Data dictionary — `Supplementary_Data_S1_clean_dataset.csv`

42 rows (one per specimen), 11 columns, no missing values.

| Column | Meaning | Units |
|---|---|---|
| `alloy` | Nominal formulation family. **Note the raw string values**: `Al-Mn-Zr`, `Al-Mn-Zr-Ce`, `Al-Mn-ZR-Y` — the third family's string has an inconsistent capitalisation (`ZR` not `Zr`) inherited from the original lab records. The code matches on these exact strings (see `feat_M1`/`RE_Y` construction) — do not "correct" the capitalisation in the CSV without updating the script, or the family filters will silently stop matching. | categorical |
| `milling_time` | High-energy ball-milling duration | h (constant, 20, across all specimens) |
| `hotpress_temp` | Hot-press consolidation temperature | °C |
| `anneal_temp` | Post-consolidation anneal temperature | °C |
| `anneal_time` | Post-consolidation anneal duration | h |
| `microhardness` | **Primary modelling target.** As-processed Vickers micro-hardness, HV0.05, specimen-level mean of up to 5 indents | HV |
| `hardness450` | Hardness after an additional 450 °C anneal (used only for the post-treatment ratio in §9, not as a modelling target) | HV |
| `grain_size` | XRD-derived coherent-domain size (Williamson–Hall analysis) — called "crystallite size" in some code comments; distinguished in the manuscript from metallographic grain size | nm |
| `aT` | Al-matrix lattice parameter — used only in the Supplementary 9-feature M3 sensitivity check (§1), excluded from the primary M3 (rests on an unverified Vegard's-law assumption in a multiphase system) | Å (or consistent lattice-parameter unit as recorded) |
| `density` | Bulk density, Archimedes method | g·cm⁻³ |
| `UTS` | Ultimate tensile strength — exploratory only, never a modelling target | MPa |

Engineered features (computed inside the script, not stored in the CSV):
`HP_term = grain_size ** -0.5` (the Hall–Petch-like term, HP = d⁻¹ᐟ²),
`RE_Ce` / `RE_Y` (one-hot indicators for the two rare-earth-containing
families, reference level = `Al-Mn-Zr`), and `condition_id` (a string key
identifying each of the 14 unique process conditions, used as the LOCO
grouping variable).

---

## 5. Reproducibility notes

**Random seeds.** Every stochastic step in the script is seeded, so a full
re-run reproduces every printed number exactly:
- `np.random.seed(42)` at the top of the script (global).
- `RandomForestRegressor(..., random_state=42)` for every primary RF fit
  (`rf_params`, defined once and reused everywhere).
- `bootstrap_ci()` defaults to `seed=42` (used for all §1 case-resampling
  intervals).
- The coefficient bootstrap in §5 uses `np.random.default_rng(42)`.
- The paired case-resampling tests in §11 use `seed=42` by default in
  `paired_test()`.
- The repeated 5-fold CV in §3 deliberately varies its seed from 0 to 19
  (that is the "20 seeds" being repeated over, not a source of
  non-reproducibility — the full set of 20 R² values is fixed).
- The 10-seed surrogate-ranking robustness check in §10 similarly varies
  `random_state` from 0 to 9 on purpose.

**Why some numbers won't match to the last decimal across machines.**
Floating-point summation order can differ slightly across BLAS/LAPACK
builds and CPU architectures, which can move the last reported decimal of
an R²/RMSE value by ~0.001–0.01 in rare cases. This does not happen with
the exact package versions in `requirements.txt` on a standard x86-64
Linux build (verified — see `run_output_reference.log`), and even where it
could occur elsewhere, it is far smaller than any of the reported
intervals.

**Speeding it up for a smoke test.** If you just want to confirm the
script runs end-to-end without waiting ~9 minutes, temporarily reduce the
bootstrap counts (`n_boot=10000` → `n_boot=500` in `bootstrap_ci()` and
`paired_test()`, `n_boot=5000` → `n_boot=500` in §5) and the permutation
importance `n_repeats=100` → `n_repeats=20` in §7. This changes the
*precision* of the printed intervals, not the point estimates, and should
**not** be done for anything you intend to compare against the published
numbers.

**Known non-issues you may notice in the output:**
- "Prediction spread across top 5: 0.00 HV" (§10) — the 21×21×3-point
  surrogate grid has several ties at its maximum; this is a real property
  of the coarse grid, not a bug, and is exactly why the manuscript treats
  the surrogate-ranking illustration as descriptive rather than as a
  validated single recommendation.
- The `Al-Mn-ZR-Y` capitalisation quirk noted in §4.
- Deprecation/convergence warnings from scikit-learn or the Gaussian
  Process baseline are suppressed (`warnings.filterwarnings('ignore')` at
  the top of the script) because they do not affect any reported number;
  remove that line if you want to see them.

---

## 6. Citation

If you reuse this code or dataset, please cite the manuscript (full
citation to be completed once the DOI is assigned) rather than this
repository alone.
